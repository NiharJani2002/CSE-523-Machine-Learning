
# Cell Nuclei Segmentation with U-Net
 
 ## BY AADYA A. CHINUBHAI

Steps to run the app on localhost :
> 0) Open CMD
> 1) mkdir your_dir
> 2) cd your_dir
> 3) git clone https://github.com/aadya940/CellSegmentationApp.git
> 4) cd CellSegmentationApp/package
> 5) pip install -r requirements.txt
> 6) cd src
> 7) streamlit run app.py


Steps to use the app :
### 0) Run the App on Localhost
### 1) Drag and Drop Image to the file Uploader
### 2) Click 'Segment'
### 3) Get the Results
